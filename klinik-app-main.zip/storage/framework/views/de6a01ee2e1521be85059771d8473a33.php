<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"> Data Layanan </div>
        <div class="card-body">
            <a href="/poli/create" class="btn btn-primary mb-3">Tambah Data</a>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th width="1%">ID</th>
                        <th>Nama Layanan</th>
                        <th width="15%">Biaya</th>
                        <th width="16%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td>
                                <div>Nama Layanan: <b><?php echo e($item->nama); ?></b></div>
                                <div>Nama Dokter: <b><?php echo e($item->dokter->nama_dokter); ?></b></div>
                                <div>Deskripsi: <?php echo e($item->deskripsi); ?></div>
                            </td>
                            <td>Rp. <?php echo e(number_format($item->biaya, 0, ',', '.')); ?></td>
                            <td>
                                <a href="/poli/<?php echo e($item->id); ?>/edit" class="btn btn-primary">
                                    Edit
                                </a>
                                <form action="/poli/<?php echo e($item->id); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"
                                        onclick="return confirm('Apakah anda yakin?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-app-main\resources\views/poli_index.blade.php ENDPATH**/ ?>