<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header"><?php echo e($judul); ?></div>
        <div class="card-body">
            <form action="/poli/<?php echo e($poli->id); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row mt-2">
                    <div class="col-md-6 form-group ">
                        <label for="nama">Nama Layanan</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama') ?? $poli->nama); ?>"
                            autofocus />
                        <span class="text-danger"><?php echo e($errors->first('nama')); ?></span>
                    </div>
                    <div class="col-md-6 form-group ">
                        <label for="biaya">Biaya</label>
                        <input type="text" name="biaya" class="form-control"
                            value="<?php echo e(old('biaya') ?? $poli->biaya); ?>" />
                        <span class="text-danger"><?php echo e($errors->first('biaya')); ?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi Layanan</label>
                    <textarea name="deskripsi" rows="3" class="form-control"><?php echo e(old('deskripsi') ?? $poli->deskripsi); ?></textarea>
                    <span class="text-danger"><?php echo e($errors->first('deskripsi')); ?></span>
                </div>
                <div class="form-group mt-2">
                    <label for="dokter_id">Pilih Dokter</label>
                    <select name="dokter_id" class="form-control">
                        <?php $__currentLoopData = $list_dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == $poli->dokter_id): echo 'selected'; endif; ?> )>
                                <?php echo e("{$item->nama_dokter} - Spesialis {$item->spesialis}"); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="text-danger"><?php echo e($errors->first('dokter_id')); ?></span>
                </div>
                <div class="form-group mt-2">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <a href="/poli" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sbadmin2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\klinik-app-main\resources\views/poli_edit.blade.php ENDPATH**/ ?>